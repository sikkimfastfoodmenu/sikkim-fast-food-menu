SIKKIM FAST FOOD & RESTAURANT — SELF-MANAGED MENU EDITOR

WHAT THIS PACKAGE CONTAINS
- index.html: customer-facing menu website
- content/menu.json: menu items, prices and availability
- admin/index.html and admin/config.yml: password/login-protected CMS editor configuration

IMPORTANT SETUP NOTES
1. This CMS requires the website to be connected to a GitHub repository. The existing Netlify Drop upload is not enough on its own.
2. Create a GitHub repository named sikkim-fast-food-menu and upload the contents of this folder to the repository root.
3. In admin/config.yml, replace REPLACE_WITH_YOUR_GITHUB_USERNAME with your GitHub username.
4. Deploy/connect that repository to Netlify. Keep the existing Netlify site name/domain if Netlify allows you to attach the repository to the existing site; otherwise you may need to change the site domain and generate a new QR code.
5. Configure Netlify's GitHub authentication for Decap CMS. The CMS GitHub backend requires a GitHub account with write access to the repository; this is not a separate standalone password. Follow current Decap CMS GitHub backend docs: https://decapcms.org/docs/github-backend/
6. After deployment, open https://YOUR-SITE.netlify.app/admin/ and sign in using the configured GitHub login. Edit the menu and save/publish. Commits trigger Netlify deployment; allow a short time for the public menu to refresh.

SECURITY / PLATFORM NOTE
Netlify Git Gateway is deprecated for new setups, so this package uses Decap CMS's GitHub backend instead. Do not publish private tokens or passwords in these files. Restrict repository write access to yourself.
This package is a starting setup, not already installed on your live website. It must be connected to GitHub and deployed before the editor works.
